/** @file Serve exact immutable retained baseline/final exports on an isolated QA loopback port. */
import { createExpoWebStaticServer } from '../../calibrate-auth-qa/scripts/expo-web-static-server.mjs';
import path from 'node:path';
const phase=process.env.QA_PHASE?.includes('before')?'before':'after';
const dir=path.resolve('../owner/implementation/'+phase+'-dist');
console.log(JSON.stringify({phase,distDir:dir,source:phase==='before'?'547206a1b372b73fc95fc412ad453b8099440000':'ff05e56ed338ec2c178dc05cdf77125d34395c67'}));
const server=createExpoWebStaticServer({distDir:dir});server.listen(18456,'127.0.0.1');
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.closeAllConnections?.();server.close(()=>process.exit(0));});
